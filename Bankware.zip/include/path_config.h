#define RESOURCES_DIRECTORY "/home/gabe/Projects/Artemis/GameDev/Bankware/resources"

