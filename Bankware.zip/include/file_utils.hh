#ifndef FILE_UTILS_H_
#define FILE_UTILS_H_

#include <string>

std::string LoadTextFile(const char *filename);

#endif // FILE_UTILS_H_
